
import DAO.MaterialBibliotecaDAO;

public class Main {
    public static void main(String[] args) {
        MaterialBibliotecaDAO dao = new MaterialBibliotecaDAO();
        System.out.println("Materiais: " + dao.getMateriais().size());
    }
}