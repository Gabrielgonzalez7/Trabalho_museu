package DAO;

import Connection.Conexao;
import model.AcervoHistorico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AcervoHistoricoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public AcervoHistoricoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir(AcervoHistorico a) {
        String sql = "INSERT INTO acervo_historico(tipo, titulo, descricao, data_item, " +
                    "palavra_chave, local_origem, doador, caminho_digitalizacao) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, a.getTipo());
            stmt.setString(2, a.getTitulo());
            stmt.setString(3, a.getDescricao());
            stmt.setDate(4, a.getDataItem());
            stmt.setString(5, a.getPalavraChave());
            stmt.setString(6, a.getLocalOrigem());
            stmt.setString(7, a.getDoador());
            stmt.setString(8, a.getCaminhoDigitalizacao());
            
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Item do acervo inserido com sucesso! Linhas afetadas: " + rowsAffected);
        } catch (Exception e) {
            System.out.println("Erro ao inserir item do acervo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public ArrayList<AcervoHistorico> getAcervo() {
        String sql = "SELECT * FROM acervo_historico ORDER BY data_item DESC;";
        ArrayList<AcervoHistorico> acervo = new ArrayList<>();
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                AcervoHistorico a = new AcervoHistorico(
                    rs.getInt("id_item"),
                    rs.getString("tipo"),
                    rs.getString("titulo"),
                    rs.getString("descricao"),
                    rs.getDate("data_item"),
                    rs.getString("palavra_chave"),
                    rs.getString("local_origem"),
                    rs.getString("doador"),
                    rs.getString("caminho_digitalizacao")
                );
                acervo.add(a);
            }
            return acervo;
        } catch (Exception e) {
            System.out.println("Erro ao consultar acervo: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public ArrayList<AcervoHistorico> buscarPorPalavraChave(String palavraChave) {
        String sql = "SELECT * FROM acervo_historico WHERE palavra_chave LIKE ? ORDER BY data_item DESC;";
        ArrayList<AcervoHistorico> acervo = new ArrayList<>();
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + palavraChave + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                AcervoHistorico a = new AcervoHistorico(
                    rs.getInt("id_item"),
                    rs.getString("tipo"),
                    rs.getString("titulo"),
                    rs.getString("descricao"),
                    rs.getDate("data_item"),
                    rs.getString("palavra_chave"),
                    rs.getString("local_origem"),
                    rs.getString("doador"),
                    rs.getString("caminho_digitalizacao")
                );
                acervo.add(a);
            }
            return acervo;
        } catch (Exception e) {
            System.out.println("Erro ao buscar por palavra-chave: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public void excluir(int id) {
        String sql = "DELETE FROM acervo_historico WHERE id_item = ?;";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Item excluído do acervo! Linhas afetadas: " + rowsAffected);
        } catch (Exception e) {
            System.out.println("Erro ao excluir item do acervo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}