USE MuseuTrezeDeMaio;

-- Empr�stimos ativos

CREATE VIEW vw_emprestimos_ativos AS
SELECT  e.id_emprestimo, u.nome AS usuario, m.titulo AS material, e.data_emprestimo, e.data_devolucao_prevista
FROM emprestimos e
JOIN usuarios u ON e.id_usuario = u.id_usuario
JOIN materiais_biblioteca m ON e.id_material = m.id_material
WHERE e.status_emprestimo = 'Ativo';

SELECT * FROM vw_emprestimos_ativos;

-- Empr�timos pendentes
CREATE VIEW vw_emprestimos_pendentes AS
SELECT e.id_emprestimo, u.nome AS usuario, m.titulo AS material, e.data_devolucao_prevista
FROM emprestimos e
JOIN usuarios u 
    ON e.id_usuario = u.id_usuario
JOIN materiais_biblioteca m 
    ON e.id_material = m.id_material
WHERE 
    e.status_emprestimo = 'Ativo'
    AND e.data_devolucao_prevista < GETDATE();

    SELECT * FROM vw_emprestimos_pendentes;



-- Hist�rico do acervo
CREATE VIEW vw_acervo_historico AS
SELECT titulo, tipo, data_item, local_origem, doador
FROM acervo_historico;
Select * from vw_acervo_historico;

