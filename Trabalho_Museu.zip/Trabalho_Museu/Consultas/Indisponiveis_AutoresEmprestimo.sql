USE MuseuTrezeDeMaio;

--Consulta de materiais atualmente indisponiveis

SELECT titulo, quantidade_exemplares
FROM materiais_biblioteca
WHERE quantidade_exemplares = 0;

-- Emprestimos em atraso
SELECT u.nome, m.titulo, e.data_devolucao_prevista
FROM emprestimos e
JOIN usuarios u ON e.id_usuario = u.id_usuario
JOIN materiais_biblioteca m ON e.id_material = m.id_material
WHERE 
    e.status_emprestimo = 'Ativo'
    AND e.data_devolucao_prevista < GETDATE();

-- Consulta que v� o autor teve mais emprestimos e quais s�o os livros

SELECT a.nome AS autor, m.titulo AS livro, COUNT(e.id_emprestimo) AS total_emprestimos_do_livro
FROM emprestimos e
JOIN materiais_biblioteca m 
    ON e.id_material = m.id_material
JOIN autores a 
    ON m.id_autor = a.id_autor
WHERE a.id_autor = (
    SELECT TOP 1 m.id_autor
    FROM emprestimos e
    JOIN materiais_biblioteca m 
        ON e.id_material = m.id_material
    GROUP BY m.id_autor
    ORDER BY COUNT(e.id_emprestimo) DESC
)
GROUP BY a.nome, m.titulo
ORDER BY total_emprestimos_do_livro DESC;
